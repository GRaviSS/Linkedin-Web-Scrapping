username_name = 'session_key'
password_name = 'session_password'
load_comments_class = 'comments-comments-list__load-more-comments-button'
comment_class = 'comments-comment-item__main-content'
name_class = 'comments-post-meta__name'
file_name = 'comments_data.csv'

# post_url = 'https://www.linkedin.com/posts/saharart_flyers-logos-businesscarddesign-activity-6693086071561056256-HTWS/'
# post_url = 'https://www.linkedin.com/posts/aimlindia_aimc-resources-giveaway-activity-6689061814338232320-O6IQ/'
# urls which I usually tested with..You can use them as demo

post_url = ''
